sudo systemctl start mysql.service
